package com.example.androidconsqlite;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Persona extends AppCompatActivity {


    private EditText cedula,nombre,apellido,actividad,telefono,horario,diregente,idComunidad;
    private Button btnAgregar,btnBuscar,btnActualizar,btnBorrar;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persona);



            cedula=(EditText)findViewById(R.id.etId);
            nombre=(EditText)findViewById(R.id.etComunidad);
            apellido=(EditText)findViewById(R.id.etCanton);
            actividad=(EditText)findViewById(R.id.etDireccion);
            telefono=(EditText)findViewById(R.id.etAsistencia);
            horario=(EditText)findViewById(R.id.etHorario);
            diregente=(EditText)findViewById(R.id.etDiregencia);
            idComunidad=(EditText)findViewById(R.id.etFk);



        btnAgregar=(Button)findViewById(R.id.btnGuardar);
            btnBuscar=(Button)findViewById(R.id.btnBuscar);
            btnActualizar=(Button)findViewById(R.id.btnActualizar);
            btnBorrar=(Button)findViewById(R.id.btnBorrar);

            btnAgregar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ejecutarServico("http://192.168.227.254/phpProyII/insertardatosAsistencia.php");
                }
            });
            btnBuscar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    buscar("http://192.168.227.254/phpProyII/buscardatosasistencia.php?cedula="+cedula.getText());
                }
            });
            btnActualizar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void  onClick(View v) {
                    actualizar("http://192.168.227.254/phpProyII/actualizarasistencia.php?cedula="+cedula.getText()+"");
                }
            });
            btnBorrar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    borrar("http://192.168.227.254/phpProyII/borrardatoasistencia.php?cedula="+cedula.getText()+"");
                }
            });
        }

        private void ejecutarServico(String URL){
            StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> parametros=new HashMap<String,String>();

                    parametros.put("Cedula",cedula.getText().toString());
                    parametros.put("Nombres",nombre.getText().toString());


                    parametros.put("Apellidos",apellido.getText().toString());
                    parametros.put("ActividadRealizada",actividad.getText().toString());
                    parametros.put("Telefono",telefono.getText().toString());
                    parametros.put("HorarioActividad",horario.getText().toString());
                    parametros.put("Diregencia",diregente.getText().toString());
                    parametros.put("fkidComunidad",idComunidad.getText().toString());

                    return parametros;
                }
            };
            requestQueue= Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }


        private void buscar(String URL){
            JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(URL, new Response.Listener<JSONArray>() {
                @Override
                public void onResponse(JSONArray response) {
                    JSONObject jsonObject = null;
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            jsonObject = response.getJSONObject(i);
                            cedula.setText(jsonObject.getString("cedula"));
                            nombre.setText(jsonObject.getString("nombres"));
                            apellido.setText(jsonObject.getString("apellidos"));
                            actividad.setText(jsonObject.getString("actividadRealizada"));
                            telefono.setText(jsonObject.getString("telefono"));
                            horario.setText(jsonObject.getString("horarioActividad"));
                            diregente.setText(jsonObject.getString("diregencia"));
                            idComunidad.setText(jsonObject.getString("fkidComunidad"));


                        } catch (JSONException e) {
                            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),"Error de conexion",Toast.LENGTH_SHORT).show();
                }
            }
            );
            requestQueue=Volley.newRequestQueue(this);
            requestQueue.add(jsonArrayRequest);
        }

        private void actualizar(String URL){
            StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> parametros=new HashMap<String,String>();
                    parametros.put("nombres",nombre.getText().toString());
                    return parametros;
                }
            };
            requestQueue= Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }
        private void borrar(String URL){
            StringRequest stringRequest=new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    Toast.makeText(getApplicationContext(), "Operacion exitosa", Toast.LENGTH_SHORT).show();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(),error.toString(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> parametros=new HashMap<String,String>();
                    return parametros;
                }
            };
            requestQueue= Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }




    public void salir(View v) {
        Toast notificacion = Toast.makeText(this, "SELECCIONE UNA OPCION", Toast.LENGTH_LONG);
        notificacion.show();

        finish();

    }
}